from turtle import Turtle, Screen
import turtle as t
t.colormode(255)
import random
t = Turtle()
t.pensize(8)
t.speed("fastest")


def random_color():
    r = random.randint(0, 255)
    g = random.randint(0, 255)
    b = random.randint(0, 255)
    return (r, g, b)



colors = ["medium slate blue", "dark orange", "orange red", "yellow", "deep sky blue", "teal", "tan", "saddle brown", "white smoke",
          "black", "light gray", "navajo white", "magenta", "spring green", "medium violet red"]
angles = [0, 90, 180, 270]
for _ in range(3000):
    # random_color = random.choice(colors)
    t.color(random_color())
    t.fd(20)
    t.setheading(random.choice(angles))



s = Screen()
s.exitonclick()