from color_extracter import rgb
import turtle as t
t.colormode(255)

from turtle import Turtle, Screen
import random

kit = Turtle()
kit.ht()
kit.speed("fastest")

kit.pu()
kit.setheading(225)
kit.forward(300)
kit.setheading(0)

for dot_count in range(1, 101):
    kit.dot(20, random.choice(rgb))
    kit.forward(50)

    if dot_count%10 == 0:
        kit.setheading(90)
        kit.forward(50)
        kit.setheading(180)
        kit.forward(500)
        kit.setheading(0)




















s = Screen()
s.exitonclick()