from turtle import Turtle, Screen
import random


colors = ["red", "purple", "blue", "yellow", "green", "violet",]
turtles = []

s = Screen()
s.setup(width=800, height=600)
user_bet = s.textinput("Make a bet", "Which colored turtle is gonna win the race? ")



# tom = Turtle(shape="turtle")
# tom.penup()
# tom.goto(x=-380, y=-100)

y = -100
for color in colors:
    t = Turtle(shape="turtle")
    t.color(color)
    t.penup()
    t.goto(-370, y)
    turtles.append(t)
    y += 35

is_on = False
if user_bet:
    is_on = True

while is_on:
    for t in turtles:
        if t.xcor() > 350:
            is_on = False
            if t.pencolor() == user_bet:
                print("You got it right! You win!")
            else:
                print("Oops, You got it wrong!", "the winner is "+t.pencolor()+" turtle.")
        random_distance = random.randint(0, 5)
        t.forward(random_distance)
s.exitonclick()






