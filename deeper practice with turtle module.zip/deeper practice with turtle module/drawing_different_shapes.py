from turtle import Turtle, Screen



tom = Turtle()
screen = Screen()
# tom.shape("turtle")
tom.color("red")
tom.pensize(2)
# for _ in range(10):
#     tom.forward(20)
#     tom.penup()
#     tom.forward(20)
#     tom.pendown()
import random
colors = ["medium slate blue", "dark orange", "orange red", "yellow", "deep sky blue", "teal", "tan", "saddle brown", "white smoke",
          "black", "light gray", "navajo white", "magenta", "spring green", "medium violet red"]
# tom.left(90)

# 1 -> 360/3 = 120
# 2 -> 360/4 = 90
# 3 -> 360/5 = 72

number_of_sides = 3
random_color = random.choice(colors)
def shapes(n):
    for _ in range(n):
        random_color = random.choice(colors)
        tom.color(random_color)
        angle = 360 / n
        tom.forward(100)
        tom.right(angle)
    if n == 8:
        return
    else:
        n += 1
        shapes(n)

shapes(number_of_sides)




screen.exitonclick()




# from prettytable import PrettyTable
#
# table = PrettyTable()
#
# table.add_column("Pokemon Name", ["Pikachu", "Ker", "Kus"])
# table.add_column("Type", ["B", "C", "D"])

# table.field_names = ["Country", "City"]
# table.add_row(["Uzbekistan", "Samarkand"])
# print(table)