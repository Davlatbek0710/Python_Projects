from turtle import Turtle, Screen
from random import randint
import turtle

turtle.colormode(255)

t = Turtle()
t.speed(60)
t.pensize(2)

def random_color():
    r = randint(0, 255)
    g = randint(0, 255)
    b = randint(0, 255)
    return (r, g, b)


angle = 3
for i in range(0, 361, 3):
    t.color(random_color())
    t.circle(100)
    t.lt(angle)

s = Screen()
s.exitonclick()
