import random
from turtle import Turtle

COLORS = ["red", "orange", "yellow", "green", "blue", "purple"]
STARTING_MOVE_DISTANCE = 5
MOVE_INCREMENT = 10


class CarManager:
    def __init__(self):
        self.cars = []

    def generate_car(self):
        if random.randint(1, 6) == 1:
            t = Turtle()
            random_color = random.choice(COLORS)
            t.color(random_color)
            t.shape("square")
            t.shapesize(stretch_wid=1, stretch_len=2)
            t.penup()
            t.setheading(180)
            random_y = random.randint(-250, 250)
            t.goto(420, random_y)
            self.cars.append(t)

    def move(self):
        for car in self.cars:
            car.forward(STARTING_MOVE_DISTANCE)

    def level_up(self):
        global STARTING_MOVE_DISTANCE
        STARTING_MOVE_DISTANCE += MOVE_INCREMENT

