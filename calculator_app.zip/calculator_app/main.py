
import os
from art import logo
# print(logo)


def add(a, b):
  return a+b
def subtract(a, b):
  return a-b
def multiply(a, b):
  return a*b
def divide(a, b):
  return a/b
  


operations = {
  "+": add,
  "-": subtract,
  "*": multiply,
  "/": divide
}


def calculator():
  print(logo)
  n1 = float(input("What's the first number? "))
  choice = "yes"
  
  while choice == "yes":
    op  = input("+\n-\n*\n/\nEnter operation: ")
    n2 = float(input("What's the next number? "))
    result = operations[op](n1, n2)
    print(f"{n1} {op} {n2} ={result}"  )
    choice = input("Do you want to continue? Type 'yes', 'no' to start again or 0 to exit. ")
    if choice == "yes":
      n1 = result
      os.system("cls")
    elif choice == "0":
      os.system("cls")
      return
    else: 
      os.system("cls")
      calculator()


calculator()
    





