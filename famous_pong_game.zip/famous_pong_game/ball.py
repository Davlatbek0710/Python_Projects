from turtle import Turtle
import random
import time
LEVELS = [0.1, 0.09, 0.006]
class Ball(Turtle):
    def __init__(self):
        super().__init__()
        self.create_ball()
        self.user_chosen_level = 0
        self.level = LEVELS[1]
        self.y_move = 3
        self.x_move = 3


    def create_ball(self):
        self.color("white")
        self.shape("circle")
        self.penup()

    def set_level(self, level):
        self.level = LEVELS[level]
        self.user_chosen_level = level
    def move(self):
        x = self.xcor() + self.x_move
        y = self.ycor() + self.y_move
        self.goto(x, y)
        time.sleep(self.level)

    def bounce_y(self):
        self.y_move *= -1

    def bounce_x(self):
        self.x_move *= -1
        self.level *= 0.5

    def reset_position(self):
        self.goto(0, 0)
        self.level = LEVELS[self.user_chosen_level]
        self.bounce_x()


