from turtle import Screen
from paddle import Paddle
from ball import Ball
from scoreboard import ScoreBoard
import time

l_pos = (-370, 0)
r_pos = (370, 0)

screen = Screen()
screen.setup(800, 600)
screen.title("My Pong Game")
screen.bgcolor("black")
screen.tracer(0)

r_paddle = Paddle(r_pos)
l_paddle = Paddle(l_pos)
ball = Ball()
scoreboard = ScoreBoard()


screen.listen()
screen.onkeypress(r_paddle.up, "Up")
screen.onkeypress(r_paddle.down, "Down")
screen.onkeypress(l_paddle.up, "w")
screen.onkeypress(l_paddle.down, "s")

level = int(screen.textinput("Choose level", "1. Slow\n2. Normal\n3. Fastest\nEnter a number: "))
ball.set_level(level - 1)

is_on = True
while is_on:
    ball.move()
    screen.update()
    # Detect collision with wall
    if ball.ycor() > 288 or ball.ycor() < -288:
        ball.bounce_y()
    # Detect collision with r_paddle
    if ball.distance(r_paddle) < 50 and ball.xcor() > 350:
        ball.bounce_x()
    # Detect collision with l_paddle
    if ball.distance(l_paddle) < 50 and ball.xcor() < -350:
        ball.bounce_x()

    # Detect if the ball is out of bounds for two players

    if ball.xcor() < -385:
        scoreboard.increase_r()
        ball.reset_position()

    if ball.xcor() > 385:
        scoreboard.increase_l()
        ball.reset_position()

screen.exitonclick()
