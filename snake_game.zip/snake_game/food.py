from turtle import Turtle
import random
import turtle
turtle.colormode(255)
TYPES_OF_FOOD = ["square", "circle", "turtle"]

class Food(Turtle):
    def __init__(self):
        super().__init__()
        self.penup()
        self.shapesize(stretch_wid=0.5, stretch_len=0.5)
        self.refresh()


    def refresh(self):
        x_cor = random.randint(-280, 280)
        y_cor = random.randint(-280, 280)
        self.shape(self.randomly_shaped_food())
        self.color(self.random_color())
        self.setpos(x_cor, y_cor)

    def randomly_shaped_food(self):
        return random.choice(TYPES_OF_FOOD)
    def random_color(self):
        r = random.randint(0, 255)
        g = random.randint(0, 255)
        b = random.randint(0, 255)
        return (r, g, b)


