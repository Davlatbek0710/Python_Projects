from snake import Snake
from turtle import Screen
from food import Food
from scoreboard import ScoreBoard
import time

screen = Screen()
screen.setup(600, 600)
screen.bgcolor("black")
screen.title("My snake game")
screen.tracer(0)

s = Snake()

screen.listen()
screen.onkey(s.up, "w")
screen.onkey(s.down, "s")
screen.onkey(s.right, "d")
screen.onkey(s.left, "a")

food = Food()
score = ScoreBoard()

is_on = True
while is_on:

    screen.update()
    time.sleep(0.1)

    s.move()

    if s.head.distance(food) < 15:
        food.refresh()
        score.increase()
        s.extend()

    # Detect wall collision
    if s.head.xcor() > 280 or s.head.xcor() < -280 or s.head.ycor() > 280 or s.head.ycor() < -280:
        score.game_over()
        is_on = False

    # Detect tail collision
    for segment in s.segments[1:]:
        if s.head.distance(segment) < 10:
            score.game_over()
            is_on = False

screen.exitonclick()
