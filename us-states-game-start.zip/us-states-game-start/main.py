import pandas

import turtle
import time

# Fetch all data form 50_states.csv
data = pandas.read_csv("50_states.csv")


# Create writer
writer = turtle.Turtle()
writer.penup()
writer.speed("fastest")
writer.hideturtle()


# Get set up screen and map
screen = turtle.Screen()
screen.setup(725, 491)
screen.title("U.S States Game")
image = "blank_states_img.gif"
turtle.addshape(image)
turtle.shape(image)

guessed_states = []

while len(guessed_states) < 50:
    user_answer = screen.textinput(title=f"{len(guessed_states)}/50 States Correct",
                                   prompt="What's another State's name? ").title()
    if user_answer == "Exit":
        all_states = data.state.to_list()
        missing_states = [state for state in all_states if state not in guessed_states]
        should_be_learnt = pandas.DataFrame(missing_states)
        should_be_learnt.to_csv("states_to_learn.csv")
        break
    elif len(data[data.state == user_answer]) != 0 and not user_answer in guessed_states:
        state = data[data.state == user_answer]
        guessed_states.append(user_answer)
        x = state.x.item()
        y = state.y.item()
        writer.goto(x, y)
        writer.write(user_answer)

screen.exitonclick()
