from menu import MENU
from menu import resources
import math

QUARTERS = 0.25
DINES = 0.10
NICKLES = 0.05
PENNIES = 0.01


def is_resource_sufficient(coffee):
    # resources that are required for making a coffee
    t_coffee = MENU[coffee]["ingredients"]

    # resources in the coffee machine+
    water = resources['water']
    milk = resources['milk']
    coffee = resources['coffee']

    if water < t_coffee['water']:
        print("Sorry there is not enough water. ")
        return False
    elif milk < t_coffee['milk']:
        print("Sorry there is not enough milk. ")
        return False
    elif coffee < t_coffee['coffee']:
        print("Sorry there is not enough coffee. ")
        return False
    else:
        return True


def is_enough_money(coffee, q, d, n, p):
    cost = MENU[coffee]['cost']
    print(f"cost of {coffee}: {MENU[coffee]['cost']}")
    ingredients = MENU[coffee]['ingredients']
    for key in MENU[coffee]['ingredients']:
        print(MENU[coffee]['ingredients'][key])
    # money data
    total = q * QUARTERS + d * DINES + n * NICKLES + p * PENNIES
    if total < cost:
        return False
    total -= cost
    resources['water'] -= ingredients['water']
    resources['milk'] -= ingredients['milk']
    resources['coffee'] -= ingredients['coffee']
    resources['money'] += cost
    print(f"Here is ${math.floor(total * 100) / 100} dollars in change. ")
    return True


def start():
    is_off = False
    while not is_off:
        request = input(" What would you like? (espresso/latte/cappuccino): ")
        if request == "espresso" or request == "latte" or request == "cappuccino":
            if is_resource_sufficient(request):
                print("Please insert coins. ")
                q = int(input("how many quarters?: "))
                d = int(input("how many dines?: "))
                n = int(input("how many nickles?: "))
                p = int(input("how many pennies?: "))
                if is_enough_money(request, q, d, n, p):
                    print(f"Here is your {request} ☕️. Enjoy!")
                else:
                    print("Sorry, there is not enough money, money refunded. ")

        elif request == "report":
            print(f"water: {resources['water']}ml\n"
                  f"milk: {resources['milk']}ml\n"
                  f"coffee: {resources['coffee']}g")
            if resources['money'] != 0:
                print(f"money: ${resources['money']}")

        elif request == "off":
            is_off = True
        else:
            print("Invalid input. ")


start()
